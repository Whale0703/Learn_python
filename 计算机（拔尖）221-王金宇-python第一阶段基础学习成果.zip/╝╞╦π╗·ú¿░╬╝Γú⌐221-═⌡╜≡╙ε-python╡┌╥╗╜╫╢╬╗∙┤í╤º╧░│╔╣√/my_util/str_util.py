def str_reverse(s):
    """
    将字符串翻转
    :param s:被翻转的字符串
    :return:返回翻转后的字符串
    """
    return s[::-1]


def substr(s, x, y):
    """

    :param s: 被切片的字符串
    :param x:起始下标
    :param y:结束下标
    :return:返回切片后的字符串
    """
    return s[x:y:]


# 测试
if __name__ == '__main__':
    print(str_reverse('hgvjhgv'))
    print(substr('adafasdfsa', 1, 6))