def print_fiLe_name(file_name):
    """
    打印文件名称
    :param file_name: 文件名
    :return: None
    """
f=None
try:
    f=open('',"r",encoding="UTF-8")
    print(f.read())
except Exception as e:
    print(e)
finally:
    if f:
        f.close()

def append_to_file(file_name,data):
    """
    将指定内容追加到文件内
    :param file_name: 被追加内容的文件名
    :param date: 指定数据
    :return: None
    """
    f=open(file_name,'a',encoding="UTF-8")
    f.write(data)
    f.write("\n")
    f.close()

if __name__=='__main__':
    # print_file_name('adfaf')
# [Errno 2] No such file or directory: ''
    append_to_file("C:/Users/WJY/Desktop/pc.txt","wdcftvgybhn")





