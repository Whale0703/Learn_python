# 2023_4_8
# if else语句
# age=int(input())
# if age>=18:
#     print("成年需要买票")
# else:不需要判断条件
#     print("have fun!")

# 案例 是否需要买票
# print("welcome to heima zoom!")
# print("please input your height")
# height=int(input())
# if height>120:
#     print("height over 120cm,please supplementary 10 yuan")
# else:
#     print("have fun!")

# if elif else语句
# case
# height=int(input("height:"))
# vip_level=int(input("please input you vip level(1-5)"))
# if height<120:
#     print("for free")
# elif vip_level>3:
#     print("vip_level>3 for free")
# else:
#     print("sorry you must supplementary 10 yuan")
# print("have fun！")


# if int(input("height:"))<120:
#     print("for free")
# elif int(input("please input you vip level(1-5)"))>3:
#     print("vip_level>3 for free")
# else:
#     print("sorry you must supplementary 10 yuan")
# print("have fun！")

# if 语句的嵌套
# if int(input("height"))>120:
#     print("sorry you are too high")
#     print("if your vip level>3 you will for free")
#     if int (input("vip_level"))>3:
#         print("free!")
#     else:
#         print("sorry you have to supplementary the ticket")
# else:
#     print("for free")

# case
# age =20
# year =3
# level=1
# if 18<age<30:
#     print("age is up to target")
#     if year>2:
#         print("congratulations! both of your year and age are up to target!")
#     elif level>3:
#         print("congratulations! both of your level and age are up to target!")
#     else:
#         print("year and level are not up to target")
# else:
#     print("gggg")

# case定义一个数字 1~10随机产生 通过三判断猜出数字
# 随机产生1~10
# 三次机会
# 猜不中会提示大了或小了
# import random
# num=random.randint(1,10)
# for i in range(3):
#     gus_num=int(input())
#     if gus_num==num:
#         print("right")
#         break
#     else:
#         if gus_num>num:
#             print("bigger!")
#         else:
#             print("lower!")

# while循环的使用
# practise
# 1到100的累加求和
# i=0
# s=0
# while i<100:
#     s+=i
#     i+=1
# print(s)

# 设置1-100的随机整数变量 通过while循环 配合input语句 判断输入的书字是否等于随机数
# 无限机会
# 猜不中会提示大了或小了
# 猜完后 提示猜了几次
# import random
# num=random.randint(1,100)
# count=0
# flag=True
# while flag:
#     gus_num=int(input("gus_num"))
#     count+=1
#     if gus_num==num:
#         flag=False
#     else:
#         if gus_num>num:
#             print("bigger")
#         else:
#             print("lower")
#
# print(f"{count}")
