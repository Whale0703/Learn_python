# 2023_4_13
# 序列的切片操作
# 序列[起始下标：结束下标：步长]
# my_str="12,34,56"
# result1=my_str[:]
# print(result1)
# result2=my_str[::-1][1:4]
# print(result2)
# result3=my_str[:][-1]
# print(result3)
# result4=my_str.split(",")[1].replace("2","")[:]
# print(result4)

# 集合的定义 元素不重复 自带去重功能 无序
# 集合使用{}
# 定义空集合时只能使用set() 若单纯使用{}会被认定为创建空字典
# 集合定义字面量
# {1,2,3,4,5,6}
# 变量名称=set()
# 添加新元素
# my_set={1,1,2,3,4,5,6,6,4,3,3,4,5}
# my_set.add("wjy")#如果添加元素已存在会自动去重
# print(f"my_set的结果为{my_set}")

# 移除元素
# my_set.remove(5)
# print(my_set)

# 随机取出元素
# print(my_set.pop())
# print(my_set)

# 清空集合
# my_set.clear()
# print(my_set)

# 取两个集合的差集 原集合不变
# my_set_1 = {1, 2, 3, 4, 5}
# my_set_2 = {3, 4, 5, 6, 7}
# my_set_3=my_set_1.difference(my_set_2)
# print(my_set_3)
# 合并集合
# my_set_3 = my_set_1.union(my_set_2)
# print(my_set_3)
# 统计集合内元素数量
# print(len(my_set_3))
# 集合的遍历 不可使用while循环进行遍历
# for element in my_set_1:
#     print(element)

# case
# 将列表中的元素 挨个取出添加进集合中并打印
# my_list=[1,2,3,4,5,6,7]
# my_set=set()
# for ele in my_list:
#     my_set.add(ele)
# print(my_set)
