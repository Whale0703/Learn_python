'''import cv2
print(cv2.getVersionString())
image=cv2.imread("gun_game_rounds_med.jpg")
print(image.shape)
cv2.imshow("image",image)
cv2.waitKey()'''
'''cv2.imshow("blue",image[:,:,0])
cv2.imshow("green",image[:,:,1])
cv2.imshow("red",image[:,:,2])'''
'''gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
cv2.imshow("gray",gray)
cv2.waitKey()
crop=image[10:170,40:200]
cv2.imshow("crop",crop)
cv2.waitKey(0)
import numpy as np
image=np.zeros([300,300,3],dtype=np.uint8)
cv2.circle(image,(150,100),20,(0,0,255),3)
cv2.waitKey(0)
import cv2

cam = cv2.VideoCapture(0)

wid = int(cam.get(3))
hei = int(cam.get(4))
size = (wid, hei)
fps = 30

fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
out = cv2.VideoWriter()
out.open(r"/home/ucar/ucar_ws/src/video/11.mp4", fourcc, fps, size)

while True:
    ret, frame = cam.read()
    if not ret:
        break
    frame = cv2.flip(frame, 1)

    out.write(frame)
    cv2.imshow("frame", frame)

    key = cv2.waitKey(100)
    if cv2.waitKey(25) & 0xFF == ord('1'):  # 当按键 1 按下
        break
cam.release()
out.release()
cv2.destroyAllWindows()'''
# 66666
# 13.14
# "我"
# name='efaf'
# _name='efaf'
# print(id(name),id(_name))
# num_1 = 23325
# num_2 = 23325
# print(num_1 is num_2)
# print(('ljy'+'sb')*20)
# # a=input("please input your name")
# # print(id(a))
# a = 1000000000000000
# b = 10
# c = 10
# del a, b, c
# print(c is a)

# print(b is c) 小整数池概念将常用的整数提前思向内存申请一部分空间 不必调用的时候再申请 浪费空间
# input 输入均以字符串类型存储 方便用户
# id（）用于输出地址
# is 用于判断地址 并以bool类型输出
# 引用计数 为0时 系统自动清除相关内存
# 分代回收 看权重 达到权重 会减少系统扫描次数 以减少时间复杂度
# 标记清除 循环引用 但无直接变量对期进行引用 我无法找到内存中对应的值 但是引用次数不为1 系统会再内存空间不够用时 自动对栈区进行检索 有变量对应的内存标记为存活
# 解压赋值 a,b,c=[1,2,3] 左右个数必须对应 否则报错
# 如果想对部分进行引用 可以使用* + 变量名 将未被引用的部分生成列表存储到变量名下
# a,*_,c=[1,2,3,4,5]
# print(a,c,_)
# 格式化输出
# print('my name is %s'%'wjy')以字符串的形式 输出后面内容 %s可以输出所有形式 而%d 仅可以输出整数
# print('my name is {3}'.format(1111,2222,33,4444)) 使用.format 可以对指定地点的内容进行输出 字符串内的内容需要用{}括起 里面可以写下标 对format后内容进行索引
# print('my name is %(name)s'%{'name':'wjy'})
# 链式赋值 可以a=b=c=10
# 交换可以使用中间变量 也可以 a,b=b,c
# 变量名存放地址 放在栈区 值存在堆区
# 可变不可变类型
# 可变类型 值改变而id不改变  list dict的key是由哈希算法计算得出为不可变类型 而value可以为任意类型
# 不可变类型 值改变id也改变  int float str 均生成新的值id也发生改变 bool
# x=11
# print(id(x))
# x=10
# print(id(x))
# not 为取反 右结合性 对紧跟着的东西取反
# and 总有两个条件均为真 才算为真
# or 为逻辑与 两条件 其中一个为真 即算为真 当左为真时 右不进行判断
# not>and>or 优先级
# 'a' in 'a'  成员运算符
# 判断 某一元素是否存在字典的key 字符串 列表
# not in 判断某一元素是否不存在于
# if 条件：
#    代码1    缩进相同算同一代码块
#    代码2
# count=1
# # while 0 < count < 100: 判断为真才执行下列操作
#     if(count >  50):
#         count += 1
#         continue
#     print(count)
#     count += 1
# l=[1,2,3,4,54,6]
# for i in l:
#     print(i)
# l.append(2)
# print(l)
# l.insert()
# print(l)
# msg1='dvsvsdbs'
# msg2='sbsbsbbx'
# msg1=msg2[:]
# print(id(msg1),id(msg2))
# a,b=0,1
# while a<1000:   斐波拉契数列
#     print(a,end=',')
#     a,b=b,a+b   解压赋值
#   print('\b')
# from datetime import datetime
# now=datetime.now()
# print(now)
# now.strftime("%x")
# now.strftime("%x")
# for i in range(1,10):
#     for j in range(1,i+1):
#         print("{}*{}={}".format(j,i,j*i),end=" ")
#     print(" ")
# from turtle import *
# fillcolor("red")
# begin_fill()
# while True:
#     forward(200)
#     right(144)
#     if abs(pos())<1:
#         break
# end_fill
# for i in range(100,999):
#     flag=1
#     for j in range(2, i):
#         if i%j==0 and i<j:
#            continue
#
#         j+=1
#     i+=1

# for i in range(2,1000):
#     flag=1
#     for a in range(2,i):
#         if i%a==0:
#             flag=0
#             break
#     if(flag):
#             print(i)