# 2023_4_16
# python异常
# 如何处理 1.整个程序因为一个BUG停止 2.对BUG进行提醒 整个程序会继续运行
# 语法
# try:
#     可能出错的语法
# except:
#     如果出错异常执行的代码
# try:
#     f=open("C:/asf.txt",'v',encoding="UTF-8")
# except:
#     f=open("C:/Users/WJY/Desktop/pc.txt",'r',encoding='UTF-8')

# 捕获指定异常
# try:
#     print(name)
# except NameError as e:
#     指定错误类型 如果try内的代码块出现的不是except所指定的错误直接报错
# print("name变量名未定义错误")
# print(e)#name 'name' is not defined

# 捕获多个指定异常仅需在except 后添加一个元组 其内部放入报错类型即可
# try:
#     print(mff)
# except (NameError,IOError) as e:
#     print(e)

#  不知道异常类型 但需要捕获 使用Exception可以捕获所有异常为

# else 未出现异常所执行的操作
# try:
#     print(2124)
# except:
#     print("出现异常")
# else:
#     print("未出现异常好耶！")

# final 无论是否出现异常 均执行的操作
# try:
#     print("测试代码")
# except:
#     print("出现问题")
# else:
#     print("未出现问题")
# finally:
#     print("我才不管出不出现问题，我都要执行")

# 异常的传递性
# def func1():
#     num=1/0
# def func2():
#     func1()
# def func():
#     try:#更改后
#         func2()
#     except Exception as e:
#         print(e)
# func()
# Traceback (most recent call last):
#   File "D:\pythonProject2\Learn_Progra.py", line 805, in <module>
#     func()
#   File "D:\pythonProject2\Learn_Progra.py", line 804, in func
#     func2()
#   File "D:\pythonProject2\Learn_Progra.py", line 802, in func2
#     func1()
#   File "D:\pythonProject2\Learn_Progra.py", line 800, in func1
#     num=1/0
#         ~^~
# ZeroDivisionError: division by zero

# python模块 模块的导入 模块能定义函数、类和变量 包含可执行的代码
# 自定义模块
# [from 模块名]import[模块|类|变量|*][as 别名]
# from 和 as可以省略
# import time#导入全部time模块
# print("start")
# time.sleep(5)#使用模块内的功能
# print("test")
# from time import sleep   #只导入time模块的sleep
# print("test")
# sleep(5)#可以直接写sleep
# print("finally")
# from time import *#导入模块全部功能
# sleep(5)#不用写模块名
# as 将导入的模块或功能改名

# 自定义模块
# 新建py文件 在内部定义函数即可
# 了解_main_变量的作用
# 写完模块需要测试 但是模块导入会执行测试模块使用_main_
# 这是另一个文件内的函数
# def add(x,y):
#     result=x+y
#     print(result)
# if __name__=='__main__':
# __name__为每个py文件的内置函数，其值为__main__
# 导入模块__name__的值
# add(1,2)
# __all__变量 当模块定义_all_时 导入模块并使用*来获取全部功能时 只能导入列表内 所指定的功能
# 即使使用__all__变量 导入时 写明具体功能名称 依旧可以获取到

# py包 作为一个文件夹 包含多个模块 区别于普通文件夹的地方再有package里会有__init__的py文件
# 这个文件内部可以不写东西 但是这是package区别于directory的唯一地方
# 引用package的方式与引用模块方式相同
# __all__变量在__init__内使用

# pip安装第三方package
# pip install 包名 连接的国外网络 网速很慢
# pip install -i 镜像网址 下载速度明显提升

# case
# import my_util.str_util as a
# from my_util import file_util as b
# b.print_fiLe_name("C:/Users/WJY/Desktop/pc.txt")

# 数据可视化
# json数据格式 轻量级 数据交互格式 可以按照JSON指定的格式去组织和封装数据
# 本质时一个带有特定格式的字符串
# JSON数据转换py字典
# import json# 可以转化列表嵌套字典 或者 字典
# data=[{'我建议':351},{'b':613},{'a':13}]
# new_=json.dumps(data)# new_=json.dumps(data，ensure_ascii=False)可以将中文原文输出
# print(type(new_),new_)
# <class 'str'> [{"\u6211\u5efa\u8bae": 351}, {"b": 613}, {"a": 13}]
# dict={"dic":1,"dic_1":2,"dic_2":3}
# json_str=json.dumps(dict,ensure_ascii=False)
# print(json_str)
# json反向转换py 使用loads（）
# s='{"dic": 1, "dic_1": 2, "dic_2": 3}'
# str_=json.loads(s)
# print(type(str_),str_)
# <class 'dict'> {'dic': 1, 'dic_1': 2, 'dic_2': 3}
