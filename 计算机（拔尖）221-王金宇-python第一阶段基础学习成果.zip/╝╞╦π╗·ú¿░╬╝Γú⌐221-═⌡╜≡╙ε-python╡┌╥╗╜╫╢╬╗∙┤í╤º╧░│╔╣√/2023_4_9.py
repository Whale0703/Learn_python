# 2023_4_9
# while的嵌套
# 注意缩进 决定层次关系
# 注意终止条件
# i=1
# while i<=100:
#     print(f"今天是第{i}天")
#     j=1
#     while j<=10:
#         print(f"这是第{j}朵")
#         j+=1
#     i+=1

# 打印九九乘法表
# i=1
# while i<=9:
#     j=1
#     while j<=i:
#         print(f"{j}*{i}={i*j}\t",end='')
#         j+=1
#     print("\n")
#     i+=1

# for的基础语法
# name=" ajfosngsg "
# for i in name:
#     print(i)
# 将字符串的内容以此取出
# for为遍历循环
# while为判断循环

# 通过for循环统计有多少个英文字母o
# str="odfnsogoagnadnadoanv"
# count=0
# for i in str:
#     if i=='o':
#         count+=1
# print(count)

# range（num1,num2,step）从num1到num2 步长为step 不包括num2
# for x in range(1,20,2):
#     print(x)

# for的变量作用域
# for i in range(10):
#     print(i)
# print(i)#此处不合规范，若要使用 可以在for循环前进行定

# for循环嵌套 注意缩进 可以与while循环一起使用

# case 使用for循环打印九九乘法表
# for i in range(1,10):
#     for j in range(1,i+1):
#         print(f"{i}*{j}={i*j}\t",end='')
#     print('\n')

# continue
# for  i in range(222):
#     print(i)
#     for j in range(223):
#         print(j)
#         continue#只作用于本级for循环，对上一级for循环不起作用
#         print(i*j)#continue跳过 此行不执行
#         #若continue替换为break 将跳过本级for循环 继续执行

# 某公司账户余额1万元 给20名员工发工资 没人1000元
# 领取工资时 财务判断员工的绩效分1-10 （随机生成）如果低于5 不发工资换下一位
# 如果工资发完了 结束发工资
# balance=1000000000
# for emplo in range(1,21):
#     import random
#     performance=random.randint(1,10)
#
#     if performance<5:
#         print(f"员工{emplo}的绩效分{performance}不满足，不发工资，下一位")
#         continue
#     if balance>=10000000:
#         balance-=100000
#         print(f"员工{emplo}满足条件 发昂工资 公司账户余额为{balance}")
#     else:
#         print(f"余额为{balance}不足以发工资 下月继续")
#         break

# 函数的定义
# def say_hi():
#     print('hi')
# 调用函数
# say_hi()

# 传入参数
# def add(x,y):
#     result=x+y
#     print(f"{x}+{y}={x+y}")
# add(4,344313243)

# 自动查核酸
# def query_nuc_acids(tem):
#     print(f"出示核算证明 并配合测量体温")
#     if tem<=37.3:
#         print(f"测量中 您的体温为{tem},体温正常，请进入")
#     else:
#         print(f"测量中 您的体温为{tem},体温异常，需要隔离！")
# query_nuc_acids(37.6)

# def add(x,y):
#     result=x+y
#     return result
# r=add(1,213)
# print(r)
# print(add(1,324))

# None类型
# def f():
#     print('sdg')
# a=f()
# print(a,type(a))
