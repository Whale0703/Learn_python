# 2023_4_12
# 通过下标索引取出链表对应元素
# my_list=[1,2,3,[4,5,6]]
# print(my_list[3][0])

# 列表的方法
# 如果将函数定义为class的成员 那么函数会称之为：方法
# 查找列表元素的下标的索引值并返回所找到的第一个下标 index(列表元素的值)
# my_list = [1, 2, 3, 4, 5]
# print(my_list.index(1))
# 如果所查找的元素不存在 会报错
# print(my_list .insert(6))

# 修改指定下标索引的元素值
# my_list [0]=2#直接赋值
# print(my_list)

# 在指定位置插入参数   insert(下标索引，插入值)
# my_list .insert(2,12345678)
# print(my_list)

# 在列表的最后追加一个元素
# my_list .append(134)
# print(my_list )

# #追加一批元素 extend（数据容器）
# my_list .extend([8,9,0])
# print(my_list )

# 元素的删除 del
# del my_list [0]
# print(my_list )

# pop取出元素 原数据容器所删除元素不再存在
# a= my_list .pop(2)
# print(a)
# print(my_list )

# 指定内容删除 从前到后 删除某元素在列表中的第一个匹配项
# my_list .remove(3)
# print(my_list)

# 清空列表
# my_list .clear()
# print(my_list )

# 统计列表内某一元素的数量 变量接受返回值
# print(my_list.count(2))

# 统计列表中所有元素的个数 len(列表名称)
# print(len(my_list))

# 列表的特点
# 列表容纳数量为2**63-1
# 可以容纳不同类型元素
# 有序存储
# 允许数据重复
# 可以修改

# 练习案例
# stu_age=[21,25,21,23,22,20]
# stu_age .append(31)
# print(stu_age)
# stu_age .extend([29,33,30])
# print(stu_age)
# stu_age .pop(0)
# stu_age .pop(-1)
# print(stu_age .index(31))

# list的遍历迭代
# my_list = [1, 2, 3, 4, 5, 6, 7, 8]
# index=0
# while index<len(my_list):
#     print(my_list [index])
#     index+=1

# for index in my_list:
#     print(index)
# index = 0

# 打印输出列表内的所有偶数 用while和for都实现一遍
# while index<len(my_list):
#     if my_list[index]==0:
#         continue
#     if my_list[index]%2==0:
#         print(my_list[index])
#     index+=1
#
# for index in my_list:
#     if my_list[index]==0:
#         continue
#     if my_list[index]%2==0:
#         print(my_list[index])

# 元组无法被修改 使用小括号 逗号隔开 数据可以是不同的数据类型
# my_tuple=(1,2,3,4,5,6,7,8,9)
# 定义空元组
# 变量名称=()#方式1
# 变量名称=tuple()#方式2
# 如果元组中只有一个数据时候 需要在该数据后添加一个逗号 以区别其他类型
# t4=(1)
# print(type(t4))#str类型
# t5=(1,)
# print(type(t5))#元组类型
# t1=(1,"2",True)
# t2=()
# t3=tuple()
# print(f"{type(t1)}，内容是{t1}")
# print(f"{type(t2)}，内容是{t2}")
# print(f"{type(t3)}，内容是{t3}")
#
# # 元组可以嵌套
# t6=(1,2,3,(4,5,6))
# print(type(t6))

# 元组通过下标索引
# t7=(1,2,3,4,5,(6,7,8,9))
# print(t7[5][1]) #打印7

# 元组操作 由于元组的不可更改性 所以方法较list更少
# index() count() len() 作用相同

# 元组的遍历
# t = (1, 2, 3, 4, 5, 6, 7, 8, 9)
# index=0
# while index<len(t):
#     print(t[index])
#     index+=1

# for index in t:
#     print(t[index])

# 元组元素虽然不可修改
# 但是可以更改 元组内部嵌套的其他可更改的数据类型
# t8=(1,2,3,[4,5,6])
# t8[3][1]=9999
# print(t8)

# 练习案例
# my_tuple=('周杰伦',11,['football','music'])
# print(my_tuple.index(11))
# print(my_tuple [0])
# del my_tuple[2][0]
# print(my_tuple)
# my_tuple[2].append('coding')
# print(my_tuple)

# 字符串 也有索引 不可修改
# 方法有index（）replace（）split（）strip（）
# my_str="aaa aaa bcd efg"
# print(my_str.index("defg"))#返回起始下标

# 字符串的替换
# my_str_=my_str.replace("a","111111")#将字符串内的全部字符串1 替换为字符串2
# #字符串本身不会发生变化 而是生成一个新的字符串
# print(my_str_)#输出为111111111111111111111111111111111111111111bcdefg

# split 按照指定的分割字符串 将字符串划分为多个字符串 并存入列表对象中
# 字符串本身不发生变化 而是生成一个新的列表对象
# my_str_=my_str.split(" ")#传入参数为以何种方式切分
# print(my_str_)#['aaa', 'aaa', 'bcd', 'efg']

# strip的规整操作
# print(my_str.strip())#不传参数的话 回去取出符串两端的空格
# print(my_str.strip("aaa"))#传入参数的话 会去除字符串两端指定参数部分
# count统计小字符串在大字符串中出现的次数
# len统计字符串的长度
