# 2023_4_14
# 字典的定义及相关操作 不允许key重复且key不为字典
# 通过key找到相关的value
# 使用{},dict()存储的是一个个键值对
# {key1:value1,key2:value2,........}
# my_dict={"a":1,"b":2,"c":3,3:4}
# print(my_dict["a"],my_dict["b"],my_dict[3])

# 字典的嵌套
# stu_dict={
# "小鱼":{
#     "语文":99,
#     "数学":88,
#     "英语":77
# },
# "小马":{
#     "语文":98,
#     "数学":87,
#     "英语":76}
# ,"小王":{
#     "语文":97,
#     "数学":86,
#     "英语":75
# }
# }
# print(stu_dict["小鱼"]["数学"])

# 字典的常用操作
# 字典[key]=value key存在即字典被修改 key不存在即新增了元素
# my_dict={'a':1,'b':2,'c':3}
# my_dict['d']=4
# print(my_dict)
# my_dict['c']=999
# print(my_dict)

# 删除元素
# quchu=my_dict.pop('c')
# print(quchu)

# 清空字典
# my_dict.clear()
# print(my_dict)

# 获取全部key
# keys=my_dict.keys()
# print(keys)
# 可以获取dict中所有value
# for key in keys:
# print(f"{my_dict[key]}\t\t",end='')

# 直接对字典进行遍历
# for key in my_dict:
#     print(key+'=',end='')
#     print(f"{my_dict[key]}    ",end='')

# 统计字典元素数量 len()
# print(len(my_dict))

# case
# dict={
#     "Mack":{
#         "部门":"科技部",
#         "工资":3000,
#         "级别":1
#     },
#     "Jack": {
#         "部门": "市场部",
#         "工资": 5000,
#         "级别": 2
#     }
# }
# for key in dict:
#     if dict[key]["级别"]==1:
#         dict[key]["级别"]+=1
#         dict[key]["工资"]+=1000
# print(dict)

# 数据容器的比较
# 数据容器的  通用  方法len() max() min()
# 容器的  通用  转换功能list(),str(),tuple(),set()
# 通用排序功能sorted() 如果需要逆序sorted(,reverse=True)

# 字符串比较大小 基于ASCII挨个成对比较 一位大则剩下不在比较 该字符串大于另一个
