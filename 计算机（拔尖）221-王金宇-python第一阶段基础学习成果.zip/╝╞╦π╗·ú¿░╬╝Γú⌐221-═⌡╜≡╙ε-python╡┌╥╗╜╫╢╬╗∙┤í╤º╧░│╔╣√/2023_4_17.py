# 2023_4_17
# pyechart 基础入门
# 导入Line功能 构造折线对象
# from pyecharts.charts import Line
# from pyecharts.options import  *
# 得到折线对象
# line=Line()
# 添加x轴数据
# line.add_xaxis(['a','b','c'])# a对应100
# 添加y轴数据
# line.add_yaxis('给y轴气的名字',[100,200,300])
# 设置全局配置 需要导入pyecharts.options
# line.set_global_opts(
#     title_opts=TitleOpts(title='title',pos_left='center',pos_bottom='1%'))

# 生成图表
# line.render()
# 运行完毕会生成一个html文件 图表在里面

# class类
# class stu:
#     name=None
#     age=None
#     gender=None
#     def say_hi(self):
#         print(f"Hi,{self.name}")
# stud=stu()
# stud.name='wjy'
# stud.say_hi()

# __init__构造方法
# class student:
#     def __init__(self,name,age,gender):
#         self.name=name
#         self.age=age
#         self.gender=gender
# stu=student('wjy',19,'man')
# print(stu.name)

# 继承
# class phone:
#     imei=None
#     def call(self):
#         print("123")
# class phone2(phone):#父类名
#     num=None
#     def call_(self):
#         print(1234)

# 类型标记
# var_1:int=10
# var_2:float=10.00
# var_3:bool=True
# var_4:str='str'

# 对函数进行注解
# class Student:
#     pass
# stu:Student=Student()

# 基础容器类型注解
# my_list:list=[1,2,3]
# my_tuple:tuple=(1,2,3)
# my_set:set={1,22,3}
# my_dict:dict={'a':1}

# 容器类型详细注解
# my_list :list[int]=[1,2,3]
# my_tuple:tuple[str,int,bool]=('sa',6,True)

# 注释中进行类型注解   不会影响类型 只是进行标注
# class student:
#     pass
# var_1 = random.Random(1,10)  #type:int
# var_2 = 0  #type:# student
# print(type(var_2))
# print(type(var_1))

# def 函数方法名(形参名：类型，行型名：类型) ->返回值注解:

# from typing import Union
#  Union类型 混合注解
# my_list:list[Union[str,int]]=[1,2,"it","sd"]

# 多态 传入不同的对象 得到不同状态
