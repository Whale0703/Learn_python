# 2023_4_10
# 函数说明文档
# def func(x,y):
#     """
#     :param x:形参x的说明
#     :param y:形参y的说明
#     :return: 返回值的说明
#     """
#     return x+y
# func()

# 函数体的嵌套调用
# def fun_a():
#     print(1)
# def fun_b():
#     fun_a()
#     print(2)
# fun_b()

# 变量的作用域
# def testA():
#     num=100
#     #num为临时存储变量，在函数执行完毕后将销毁，所以无法在函数外进行引用
#     print(num)

# 如果将num设置为全局变量 则在函数外仍可以使用
# num=100
# def testA():
#     print(num)
# testA()

# global关键字可以使得函数内部变量变为全局变量
# 可在函数内部对全局变量的数值进行更改
# num=100
# def func():
#     global num
#     num=200
# func()
# print(num)

# 数据容器 可以容纳多份数据
# list列表
# [元素1，元素2.......]
# 定义变量
# 变量名=[1,2,3,4]
# 定义空列表
# 变量名称=[]
# 变量名称=list()
# 列表的嵌套
# [[1,2,3,4],[5,6,7],[8,9,0]]
