# 2023_4_11
# 函数章节的综合案例
# money=5000000
# name=None
# #用户输入姓名
# name=input("请输入您的姓名：")
# def deposit(num):
#     print("-------存款-------")
#     global money
#     money+=num
#     print(f"{name}您好！，您存款{num}元成功！")
#     query(False)
#
# def withdrawal(num):
#     print("-------取款-------")
#     global money
#     money-=num
#     print(f"{name}您好！您取款{num}元成功！")
#     query(False)
#
# 定义查询函数
# def query(show_head):
#     if show_head:
#         print("-------查询余额-------")
#     print(f"{name}您好！您的余额为：{money}元")
#
# def main():
#     print("-------主菜单-------")
#     print(f"{name}你好！")
#     print("查询\t\t[输入1]")
#     print("存款\t\t[输入2]")
#     print("取款\t\t[输入3]")
#     print("退出\t\t[输入4]")
#     return input("请输入你的选择：")
# while True:
#     key_board=main()
#     if key_board =="1":
#         query(True)
#         continue
#     elif key_board == "2":
#         num=int(input("您想存多少钱"))
#         deposit(num)
#         continue
#
#     elif key_board == "3":
#         num=int(input("您想取多少钱"))
#         withdrawal(num)
#         continue
#     else :
#         print("程序退出！！")
#         break
