# 2023_4_15
# 函数如果需要多个返回值
# def test():
#     return 1,2
# x,y=test()
# 按照返回值的顺序，写对应的多个变量接受即可，逗号隔开

# 函数的多种传参方式
# 位置参数(传入参数和形参变量一一对应)
# 关键字参数
# def info(name,age,gender):
#     print(f"{name},{age},{gender}")
# 关键字传参 可以不按固定位置
# info(name="Jack",age=18,gender="Men")
# 与位置参数混用 位置参数必须在前 且匹配参数顺序
# info("Makc",age=28,gender="Woman")

# 缺省参数 缺省参数为参数提供默认值 调用函数可不传该默认参数的值
# （默认参数必须放在最后面 包括函数定义和调用）
# def f(test="默认"):
#     print(f"{test}")
# f()
# f(test="默认值可被覆盖")

# 不定长参数传递
# def f(*args):
#     print(args)
# 形参前加一个* 传入位置参数数量不限且都会被args变量收集 会根据参入参数的位置合并为一个元组

# 关键字传递 定义时 形参前要加两个**  传入参数均会被形参接受并合并为字典
# 参数为  key=value
# def f(**kwargs):
#     print(kwargs)
# f(name="name",age=18,id=123)

# 函数作为参数传递
# def test_f(add):
#     print("result=",add(1,2))
# def add(x,y):
#     return x+y
# test_f(add)

# lambda匿名函数 临时构建一个函数 只能用一次
# 语法
# def test_func(add):
#     print(add(11,22))
#     print(type(add))
# test_func(lambda x,y:x+y)# lambda 传入参数:函数体(一行代码)
# 定义add的执行逻辑是x+y

# 文件编码
# 文件的读取操作
# open(name,mode,encoding)
# name:目标文件名的字符串 路径
# mode:设置打开文件的模式 只读、写入、追加等
# r:只读 文件指针放于文件开头 默认模式
# w:写入 文件存在 对原有内容进行覆盖写入 文件不存在 创建文件
# a:追加 文件存在 新的内容被写入至已有内容之后 否则 创建新文件进行写入
# encoding:编码格式 UTF-8 GBK等
# f=open("C:/Users/WJY/Desktop/pc.txt",'r',encoding='UTF-8')
# encoding的位置实际上是第四位 前面有一个buffering=-1的形参被省略了 所以需要关键字传参
# print(type(f))
# print(f)

# read(num)从文件中获取指定长度的字节 如果不传入num 则表示读取文件中所有的数据
# print(f.read())#连续调用 会从上一次读取的位置继续读写
# readlines() 读取全部行 并封装到列表中
# readline() 读取一行
# for line in f:#循环读取全部行
#     print(line)
# 关闭文件 解除占用
# f.close()
# time.sleep(20200202)#暂停执行
# 自动关闭文件 with内代码块执行完毕后 自动关闭所占用的文件
# with open("C:/Users/WJY/Desktop/pc.txt",'r',encoding='UTF-8') as f:
#     for line in f:
#         print(line)
# 文件的写入
#     f.write("wjy")
# 文件的刷新 调用write时 内容积攒在程序的缓冲区中
# 在调用flush() 或者文件关闭时候才会一次性写入硬盘
