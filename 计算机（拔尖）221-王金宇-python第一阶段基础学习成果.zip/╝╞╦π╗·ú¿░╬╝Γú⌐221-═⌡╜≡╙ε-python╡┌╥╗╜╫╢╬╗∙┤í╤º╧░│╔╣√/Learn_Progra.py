# 2023_4_7
# money=50
# print("冰淇淋花费10元")
# money = money-10
# print("可乐花费5元")
# money=money-5
# print("最终剩下",money)
# num_1=102
# #格式化输入的精度控制
# print("%8.0d"%num_1)
# 表达是的格式化输出 快速格式化的运用
# name="公司"
# stock_price=17.22
# stock_code ='002365'
# stock_price_dai_grow_fac=1.2
# gro_days=7
# print(f"{name},股票代码：{stock_code },当前股价：{stock_price }")
# print("每日增长系数为%d，经过%d天增长后，股价达到了%.2f"%(stock_price_dai_grow_fac ,gro_days ,stock_price*(stock_price_dai_grow_fac**1.2)))
import random
import time

# print("儿童免费，成人收费")
# age=int(input())
# if age>=18:
#     print("补票去 10元")
# print('玩的愉快')
















