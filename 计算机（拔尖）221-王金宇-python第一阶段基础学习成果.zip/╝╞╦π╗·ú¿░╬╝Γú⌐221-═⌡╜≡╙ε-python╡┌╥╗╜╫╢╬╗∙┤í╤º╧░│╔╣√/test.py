__all__=['add']

def add(x,y):
    result=x+y
    print(result)

def mul(x,y):
    result=x*y
    print(result)
print(__name__)
if __name__=='__main__':
    add(1,2)
    print(__name__)